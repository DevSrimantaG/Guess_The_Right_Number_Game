package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    innerPadding
                  AppUI()
                }
            }
        }
    }
}
@SuppressLint("RememberReturnType")
@Composable
fun AppUI() {
    val hint = remember {
        mutableStateOf("")
    }
    val number = remember {
        mutableStateOf("")
    }
    val rand = remember {
        mutableIntStateOf(randNum())
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        Text(fontFamily = FontFamily.Cursive,
            fontSize = 30.sp,
            color = Color.Green,
            text = "Guess The Right Number -> ${rand.value}")
        Text(text = "${hint.value}")
        Card(modifier = Modifier
            .width(100.dp)
            .height(60.dp)
            ) {
            Text(fontSize = 40.sp,
                text = "${number.value}")
        }
        Card() {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround){
                    Button(onClick = {number.value=number.value +"1"}) {
                        Text(text = "1")
                    }
                    Button(onClick = {number.value=number.value +"2"}) {
                        Text(text = "2")
                    }
                    Button(onClick = {number.value=number.value +"3"}) {
                        Text(text = "3")
                    }
                }
                Row (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround){
                    Button(onClick = {number.value=number.value +"4"}) {
                        Text(text = "4")
                    }
                    Button(onClick = {number.value=number.value +"5"}) {
                        Text(text = "5")
                    }
                    Button(onClick = {number.value=number.value +"6"}) {
                        Text(text = "6")
                    }

                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround){
                    Button(onClick = {number.value=number.value +"7"}) {
                        Text(text = "7")
                    }
                    Button(onClick = {number.value=number.value +"8"}) {
                        Text(text = "8")
                    }
                    Button(onClick = {number.value=number.value +"9"}) {
                        Text(text = "9")
                    }

                }
                Row (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround){
                    Button(onClick = {number.value=number.value +"0"}) {
                        Text(text = "0")
                    }
                    Button(onClick = {
                        number.value=number.value.dropLast(1)
                    }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "")
                    }
                    Button(onClick = {
                        hint.value = check(randomNum = rand.value, num = number.value.toInt())
                        number.value = ""
                    }) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = "")
                    }
                }
                Column(modifier = Modifier.fillMaxWidth()) {}
                Button(onClick = {
                    rand.value = randNum()
                }) {
                    Text(text = "Play Again")
                }
            }
        }
    }
}
fun check(randomNum : Int ,num : Int): String {
    if (randomNum > num) {
        return "$num is Small"
    }
    else if (randomNum < num) {
        return "$num is Big"
    }
    else {
        return "Your Guess is Right"
    }
}
fun randNum():Int {
    return Random.nextInt(1,99)
}

